
import React from 'react';

const ThemeSwitcher: React.FC = () => {
  return null; // No theme switcher needed since we only support dark mode
};

export default ThemeSwitcher;
