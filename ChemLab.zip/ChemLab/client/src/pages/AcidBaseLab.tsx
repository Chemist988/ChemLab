import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Beaker, Droplets, AlertTriangle, CheckCircle, RotateCcw, Search } from 'lucide-react';
import { getAnimationClass } from '@/utils/reactionUtils';

interface AcidBaseSolution {
  id: string;
  name: string;
  type: 'acid' | 'base' | 'neutral';
  ph: number;
  concentration: number;
  color: string;
  formula: string;
  description: string;
}

interface ReactionResult {
  product: string;
  finalPh: number;
  description: string;
  animation: string;
  safety: 'safe' | 'caution' | 'danger';
  productColor: string;
  isReacting: boolean;
}

const AcidBaseLab: React.FC = () => {
  const [selectedAcid, setSelectedAcid] = useState<AcidBaseSolution | null>(null);
  const [selectedBase, setSelectedBase] = useState<AcidBaseSolution | null>(null);
  const [reactionResult, setReactionResult] = useState<ReactionResult | null>(null);
  const [isReacting, setIsReacting] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAcids, setShowAcids] = useState(true);
  const [showBases, setShowBases] = useState(true);
  
  // Animation states (copied from ReactionZone)
  const [bubbles, setBubbles] = useState<number[]>([]);
  const [explosion, setExplosion] = useState(false);
  const [gas, setGas] = useState(false);
  const [splash, setSplash] = useState(false);
  const [steam, setSteam] = useState(false);
  const [crystallization, setCrystallization] = useState(false);
  const [heatWaves, setHeatWaves] = useState(false);
  const [colorChange, setColorChange] = useState(false);
  const [precipitation, setPrecipitation] = useState(false);
  const [flames, setFlames] = useState(false);
  const [windEffect, setWindEffect] = useState(false);
  const [plasmaBurst, setPlasmaBurst] = useState(false);
  const [radioactiveGlow, setRadioactiveGlow] = useState(false);
  const [chemicalSpiral, setChemicalSpiral] = useState(false);
  const [molecularDance, setMolecularDance] = useState(false);
  const [quantumFlicker, setQuantumFlicker] = useState(false);

  const allSolutions: AcidBaseSolution[] = [
    // Strong Acids (pH 0-2)
    { id: 'hcl', name: 'Hydrochloric Acid', type: 'acid', ph: 1.0, concentration: 1.0, color: 'text-red-600', formula: 'HCl', description: 'Strong acid found in stomach acid' },
    { id: 'h2so4', name: 'Sulfuric Acid', type: 'acid', ph: 0.5, concentration: 1.0, color: 'text-red-700', formula: 'H₂SO₄', description: 'Battery acid, highly corrosive' },
    { id: 'hno3', name: 'Nitric Acid', type: 'acid', ph: 0.8, concentration: 1.0, color: 'text-red-600', formula: 'HNO₃', description: 'Used in fertilizers and explosives' },
    { id: 'hbr', name: 'Hydrobromic Acid', type: 'acid', ph: 0.9, concentration: 1.0, color: 'text-red-600', formula: 'HBr', description: 'Strong halogen acid' },
    { id: 'hi', name: 'Hydroiodic Acid', type: 'acid', ph: 1.1, concentration: 1.0, color: 'text-red-600', formula: 'HI', description: 'Strongest halogen acid' },
    { id: 'hclo4', name: 'Perchloric Acid', type: 'acid', ph: 0.3, concentration: 1.0, color: 'text-red-700', formula: 'HClO₄', description: 'Extremely strong acid' },
    { id: 'h3po4', name: 'Phosphoric Acid', type: 'acid', ph: 1.5, concentration: 1.0, color: 'text-red-500', formula: 'H₃PO₄', description: 'Used in soft drinks' },
    { id: 'hf', name: 'Hydrofluoric Acid', type: 'acid', ph: 1.8, concentration: 1.0, color: 'text-red-500', formula: 'HF', description: 'Can etch glass, very dangerous' },
    { id: 'h2s', name: 'Hydrogen Sulfide', type: 'acid', ph: 2.0, concentration: 0.1, color: 'text-orange-600', formula: 'H₂S', description: 'Rotten egg smell' },
    { id: 'hclo3', name: 'Chloric Acid', type: 'acid', ph: 1.2, concentration: 1.0, color: 'text-red-600', formula: 'HClO₃', description: 'Strong oxidizing acid' },
    
    // Moderate Acids (pH 2-4)
    { id: 'ch3cooh', name: 'Acetic Acid', type: 'acid', ph: 2.9, concentration: 1.0, color: 'text-orange-500', formula: 'CH₃COOH', description: 'Vinegar, food preservative' },
    { id: 'citric', name: 'Citric Acid', type: 'acid', ph: 2.2, concentration: 0.1, color: 'text-orange-400', formula: 'C₆H₈O₇', description: 'Found in citrus fruits' },
    { id: 'formic', name: 'Formic Acid', type: 'acid', ph: 2.4, concentration: 1.0, color: 'text-orange-500', formula: 'HCOOH', description: 'Found in ant stings' },
    { id: 'lactic', name: 'Lactic Acid', type: 'acid', ph: 2.4, concentration: 0.1, color: 'text-orange-400', formula: 'C₃H₆O₃', description: 'Produced in muscles during exercise' },
    { id: 'oxalic', name: 'Oxalic Acid', type: 'acid', ph: 1.3, concentration: 0.1, color: 'text-red-400', formula: 'C₂H₂O₄', description: 'Found in rhubarb and spinach' },
    { id: 'tartaric', name: 'Tartaric Acid', type: 'acid', ph: 2.0, concentration: 0.1, color: 'text-orange-500', formula: 'C₄H₆O₆', description: 'Used in baking powder' },
    { id: 'malic', name: 'Malic Acid', type: 'acid', ph: 2.3, concentration: 0.1, color: 'text-orange-400', formula: 'C₄H₆O₅', description: 'Found in apples' },
    { id: 'benzoic', name: 'Benzoic Acid', type: 'acid', ph: 2.8, concentration: 0.1, color: 'text-orange-400', formula: 'C₇H₆O₂', description: 'Food preservative' },
    { id: 'salicylic', name: 'Salicylic Acid', type: 'acid', ph: 2.9, concentration: 0.1, color: 'text-orange-400', formula: 'C₇H₆O₃', description: 'Used in aspirin' },
    { id: 'ascorbic', name: 'Ascorbic Acid', type: 'acid', ph: 2.1, concentration: 0.1, color: 'text-orange-400', formula: 'C₆H₈O₆', description: 'Vitamin C' },
    
    // Weak Acids (pH 4-6)
    { id: 'carbonic', name: 'Carbonic Acid', type: 'acid', ph: 5.6, concentration: 0.01, color: 'text-yellow-500', formula: 'H₂CO₃', description: 'Forms when CO₂ dissolves in water' },
    { id: 'boric', name: 'Boric Acid', type: 'acid', ph: 5.2, concentration: 0.1, color: 'text-yellow-500', formula: 'H₃BO₃', description: 'Mild antiseptic' },
    { id: 'humic', name: 'Humic Acid', type: 'acid', ph: 4.5, concentration: 0.01, color: 'text-yellow-600', formula: 'Complex', description: 'Soil organic matter' },
    { id: 'tannic', name: 'Tannic Acid', type: 'acid', ph: 4.2, concentration: 0.1, color: 'text-yellow-600', formula: 'C₇₆H₅₂O₄₆', description: 'Found in tea and wine' },
    { id: 'gallic', name: 'Gallic Acid', type: 'acid', ph: 4.4, concentration: 0.1, color: 'text-yellow-600', formula: 'C₇H₆O₅', description: 'Found in gallnuts' },
    { id: 'uric', name: 'Uric Acid', type: 'acid', ph: 5.4, concentration: 0.01, color: 'text-yellow-500', formula: 'C₅H₄N₄O₃', description: 'Metabolic waste product' },
    { id: 'hippuric', name: 'Hippuric Acid', type: 'acid', ph: 4.9, concentration: 0.1, color: 'text-yellow-500', formula: 'C₉H₉NO₃', description: 'Urine component' },
    { id: 'succinic', name: 'Succinic Acid', type: 'acid', ph: 4.2, concentration: 0.1, color: 'text-yellow-600', formula: 'C₄H₆O₄', description: 'Metabolic intermediate' },
    { id: 'fumaric', name: 'Fumaric Acid', type: 'acid', ph: 4.4, concentration: 0.1, color: 'text-yellow-600', formula: 'C₄H₄O₄', description: 'Food additive' },
    { id: 'glutamic', name: 'Glutamic Acid', type: 'acid', ph: 4.3, concentration: 0.1, color: 'text-yellow-600', formula: 'C₅H₉NO₄', description: 'Amino acid' },
    
    // Additional Acids (continuing to reach 100+)
    { id: 'palmitic', name: 'Palmitic Acid', type: 'acid', ph: 5.8, concentration: 0.01, color: 'text-yellow-400', formula: 'C₁₆H₃₂O₂', description: 'Fatty acid in palm oil' },
    { id: 'stearic', name: 'Stearic Acid', type: 'acid', ph: 5.9, concentration: 0.01, color: 'text-yellow-400', formula: 'C₁₈H₃₆O₂', description: 'Saturated fatty acid' },
    { id: 'oleic', name: 'Oleic Acid', type: 'acid', ph: 5.7, concentration: 0.01, color: 'text-yellow-400', formula: 'C₁₈H₃₄O₂', description: 'Monounsaturated fatty acid' },
    { id: 'linoleic', name: 'Linoleic Acid', type: 'acid', ph: 5.6, concentration: 0.01, color: 'text-yellow-400', formula: 'C₁₈H₃₂O₂', description: 'Essential fatty acid' },
    { id: 'arachidonic', name: 'Arachidonic Acid', type: 'acid', ph: 5.5, concentration: 0.01, color: 'text-yellow-400', formula: 'C₂₀H₃₂O₂', description: 'Omega-6 fatty acid' },
    { id: 'butyric', name: 'Butyric Acid', type: 'acid', ph: 4.8, concentration: 0.1, color: 'text-yellow-500', formula: 'C₄H₈O₂', description: 'Butter acid' },
    { id: 'propionic', name: 'Propionic Acid', type: 'acid', ph: 4.9, concentration: 0.1, color: 'text-yellow-500', formula: 'C₃H₆O₂', description: 'Food preservative' },
    { id: 'valeric', name: 'Valeric Acid', type: 'acid', ph: 4.8, concentration: 0.1, color: 'text-yellow-500', formula: 'C₅H₁₀O₂', description: 'Unpleasant odor' },
    { id: 'caproic', name: 'Caproic Acid', type: 'acid', ph: 4.9, concentration: 0.1, color: 'text-yellow-500', formula: 'C₆H₁₂O₂', description: 'Goat smell' },
    { id: 'caprylic', name: 'Caprylic Acid', type: 'acid', ph: 5.0, concentration: 0.1, color: 'text-yellow-500', formula: 'C₈H₁₆O₂', description: 'Medium-chain fatty acid' },
    { id: 'lauric', name: 'Lauric Acid', type: 'acid', ph: 5.3, concentration: 0.01, color: 'text-yellow-400', formula: 'C₁₂H₂₄O₂', description: 'Found in coconut oil' },
    { id: 'myristic', name: 'Myristic Acid', type: 'acid', ph: 5.5, concentration: 0.01, color: 'text-yellow-400', formula: 'C₁₄H₂₈O₂', description: 'Saturated fatty acid' },
    { id: 'adipic', name: 'Adipic Acid', type: 'acid', ph: 4.4, concentration: 0.1, color: 'text-yellow-600', formula: 'C₆H₁₀O₄', description: 'Used in nylon production' },
    { id: 'sebacic', name: 'Sebacic Acid', type: 'acid', ph: 4.7, concentration: 0.1, color: 'text-yellow-500', formula: 'C₁₀H₁₈O₄', description: 'Used in plastics' },
    { id: 'azelaic', name: 'Azelaic Acid', type: 'acid', ph: 4.6, concentration: 0.1, color: 'text-yellow-500', formula: 'C₉H₁₆O₄', description: 'Skincare ingredient' },
    { id: 'suberic', name: 'Suberic Acid', type: 'acid', ph: 4.5, concentration: 0.1, color: 'text-yellow-500', formula: 'C₈H₁₄O₄', description: 'Dicarboxylic acid' },
    { id: 'pimelic', name: 'Pimelic Acid', type: 'acid', ph: 4.7, concentration: 0.1, color: 'text-yellow-500', formula: 'C₇H₁₂O₄', description: 'Industrial intermediate' },
    { id: 'glutaric', name: 'Glutaric Acid', type: 'acid', ph: 4.3, concentration: 0.1, color: 'text-yellow-600', formula: 'C₅H₈O₄', description: 'Dicarboxylic acid' },
    { id: 'malonic', name: 'Malonic Acid', type: 'acid', ph: 2.8, concentration: 0.1, color: 'text-orange-400', formula: 'C₃H₄O₄', description: 'Synthetic precursor' },
    { id: 'methylmalonic', name: 'Methylmalonic Acid', type: 'acid', ph: 3.1, concentration: 0.1, color: 'text-orange-400', formula: 'C₄H₆O₄', description: 'Metabolic marker' },
    { id: 'ethylmalonic', name: 'Ethylmalonic Acid', type: 'acid', ph: 3.2, concentration: 0.1, color: 'text-orange-400', formula: 'C₅H₈O₄', description: 'Metabolic disorder marker' },
    
    // Strong Bases (pH 12-14)
    { id: 'naoh', name: 'Sodium Hydroxide', type: 'base', ph: 14.0, concentration: 1.0, color: 'text-blue-600', formula: 'NaOH', description: 'Lye, drain cleaner' },
    { id: 'koh', name: 'Potassium Hydroxide', type: 'base', ph: 13.8, concentration: 1.0, color: 'text-blue-600', formula: 'KOH', description: 'Caustic potash' },
    { id: 'lioh', name: 'Lithium Hydroxide', type: 'base', ph: 13.5, concentration: 1.0, color: 'text-blue-600', formula: 'LiOH', description: 'Used in batteries' },
    { id: 'caoh2', name: 'Calcium Hydroxide', type: 'base', ph: 12.4, concentration: 0.1, color: 'text-blue-500', formula: 'Ca(OH)₂', description: 'Lime water' },
    { id: 'baoh2', name: 'Barium Hydroxide', type: 'base', ph: 13.3, concentration: 1.0, color: 'text-blue-600', formula: 'Ba(OH)₂', description: 'Strong alkaline' },
    { id: 'sroh2', name: 'Strontium Hydroxide', type: 'base', ph: 13.1, concentration: 1.0, color: 'text-blue-600', formula: 'Sr(OH)₂', description: 'Alkaline earth hydroxide' },
    { id: 'mgoh2', name: 'Magnesium Hydroxide', type: 'base', ph: 10.5, concentration: 0.01, color: 'text-cyan-500', formula: 'Mg(OH)₂', description: 'Milk of magnesia' },
    { id: 'aloh3', name: 'Aluminum Hydroxide', type: 'base', ph: 9.0, concentration: 0.01, color: 'text-green-400', formula: 'Al(OH)₃', description: 'Antacid ingredient' },
    { id: 'beoh2', name: 'Beryllium Hydroxide', type: 'base', ph: 8.5, concentration: 0.01, color: 'text-green-400', formula: 'Be(OH)₂', description: 'Amphoteric hydroxide' },
    { id: 'rboh', name: 'Rubidium Hydroxide', type: 'base', ph: 13.9, concentration: 1.0, color: 'text-blue-600', formula: 'RbOH', description: 'Alkali metal hydroxide' },
    { id: 'csoh', name: 'Cesium Hydroxide', type: 'base', ph: 14.1, concentration: 1.0, color: 'text-blue-700', formula: 'CsOH', description: 'Strongest base' },
    
    // Moderate to Weak Bases (pH 8-12)
    { id: 'nh3', name: 'Ammonia', type: 'base', ph: 11.1, concentration: 1.0, color: 'text-cyan-400', formula: 'NH₃', description: 'Household cleaner' },
    { id: 'nahco3', name: 'Sodium Bicarbonate', type: 'base', ph: 8.3, concentration: 0.1, color: 'text-green-400', formula: 'NaHCO₃', description: 'Baking soda' },
    { id: 'na2co3', name: 'Sodium Carbonate', type: 'base', ph: 11.6, concentration: 0.1, color: 'text-cyan-400', formula: 'Na₂CO₃', description: 'Washing soda' },
    { id: 'k2co3', name: 'Potassium Carbonate', type: 'base', ph: 11.5, concentration: 0.1, color: 'text-cyan-400', formula: 'K₂CO₃', description: 'Potash' },
    { id: 'li2co3', name: 'Lithium Carbonate', type: 'base', ph: 11.2, concentration: 0.1, color: 'text-cyan-500', formula: 'Li₂CO₃', description: 'Mood stabilizer' },
    { id: 'na3po4', name: 'Sodium Phosphate', type: 'base', ph: 12.0, concentration: 0.1, color: 'text-blue-400', formula: 'Na₃PO₄', description: 'Cleaning agent' },
    { id: 'na2hpo4', name: 'Disodium Phosphate', type: 'base', ph: 9.1, concentration: 0.1, color: 'text-green-400', formula: 'Na₂HPO₄', description: 'Buffer solution' },
    { id: 'nahpo4', name: 'Monosodium Phosphate', type: 'base', ph: 4.7, concentration: 0.1, color: 'text-yellow-500', formula: 'NaH₂PO₄', description: 'Acidic salt' },
    { id: 'nh4oh', name: 'Ammonium Hydroxide', type: 'base', ph: 11.1, concentration: 1.0, color: 'text-cyan-400', formula: 'NH₄OH', description: 'Aqueous ammonia' },
    { id: 'methylamine', name: 'Methylamine', type: 'base', ph: 11.8, concentration: 1.0, color: 'text-cyan-400', formula: 'CH₃NH₂', description: 'Organic base' },
    { id: 'ethylamine', name: 'Ethylamine', type: 'base', ph: 11.9, concentration: 1.0, color: 'text-cyan-400', formula: 'C₂H₅NH₂', description: 'Organic base' },
    { id: 'diethylamine', name: 'Diethylamine', type: 'base', ph: 11.0, concentration: 1.0, color: 'text-cyan-500', formula: '(C₂H₅)₂NH', description: 'Secondary amine' },
    { id: 'triethylamine', name: 'Triethylamine', type: 'base', ph: 10.8, concentration: 1.0, color: 'text-cyan-500', formula: '(C₂H₅)₃N', description: 'Tertiary amine' },
    { id: 'pyridine', name: 'Pyridine', type: 'base', ph: 9.0, concentration: 1.0, color: 'text-green-400', formula: 'C₅H₅N', description: 'Aromatic base' },
    { id: 'piperidine', name: 'Piperidine', type: 'base', ph: 11.2, concentration: 1.0, color: 'text-cyan-500', formula: 'C₅H₁₁N', description: 'Cyclic amine' },
    { id: 'morpholine', name: 'Morpholine', type: 'base', ph: 8.3, concentration: 1.0, color: 'text-green-400', formula: 'C₄H₉NO', description: 'Heterocyclic amine' },
    { id: 'aniline', name: 'Aniline', type: 'base', ph: 4.6, concentration: 1.0, color: 'text-yellow-500', formula: 'C₆H₅NH₂', description: 'Aromatic amine' },
    { id: 'imidazole', name: 'Imidazole', type: 'base', ph: 7.0, concentration: 1.0, color: 'text-gray-400', formula: 'C₃H₄N₂', description: 'Histidine component' },
    { id: 'guanidine', name: 'Guanidine', type: 'base', ph: 12.5, concentration: 1.0, color: 'text-blue-400', formula: 'CH₅N₃', description: 'Strong organic base' },
    { id: 'hydrazine', name: 'Hydrazine', type: 'base', ph: 8.1, concentration: 1.0, color: 'text-green-400', formula: 'N₂H₄', description: 'Rocket fuel component' },
    { id: 'hydroxylamine', name: 'Hydroxylamine', type: 'base', ph: 6.0, concentration: 1.0, color: 'text-gray-400', formula: 'NH₂OH', description: 'Reducing agent' },
    
    // Additional Bases and Complex Solutions
    { id: 'tris', name: 'Tris Buffer', type: 'base', ph: 8.1, concentration: 0.1, color: 'text-green-400', formula: 'C₄H₁₁NO₃', description: 'Biological buffer' },
    { id: 'hepes', name: 'HEPES Buffer', type: 'base', ph: 7.5, concentration: 0.1, color: 'text-gray-400', formula: 'C₈H₁₈N₂O₄S', description: 'Zwitterionic buffer' },
    { id: 'bis_tris', name: 'Bis-Tris Buffer', type: 'base', ph: 6.5, concentration: 0.1, color: 'text-gray-400', formula: 'C₈H₁₉NO₅', description: 'Good buffer for proteins' },
    { id: 'tricine', name: 'Tricine Buffer', type: 'base', ph: 8.1, concentration: 0.1, color: 'text-green-400', formula: 'C₆H₁₃NO₅', description: 'Good buffer for biochemistry' },
    { id: 'bicine', name: 'Bicine Buffer', type: 'base', ph: 8.3, concentration: 0.1, color: 'text-green-400', formula: 'C₆H₁₃NO₄', description: 'Zwitterionic buffer' },
    { id: 'ches', name: 'CHES Buffer', type: 'base', ph: 9.3, concentration: 0.1, color: 'text-green-500', formula: 'C₈H₁₇NO₃S', description: 'Good buffer at high pH' },
    { id: 'caps', name: 'CAPS Buffer', type: 'base', ph: 10.4, concentration: 0.1, color: 'text-cyan-500', formula: 'C₉H₁₉NO₃S', description: 'High pH buffer' },
    { id: 'ethanolamine', name: 'Ethanolamine', type: 'base', ph: 9.5, concentration: 1.0, color: 'text-green-500', formula: 'C₂H₇NO', description: 'Industrial chemical' },
    { id: 'diethanolamine', name: 'Diethanolamine', type: 'base', ph: 8.9, concentration: 1.0, color: 'text-green-400', formula: 'C₄H₁₁NO₂', description: 'Surfactant precursor' },
    { id: 'triethanolamine', name: 'Triethanolamine', type: 'base', ph: 7.8, concentration: 1.0, color: 'text-gray-500', formula: 'C₆H₁₅NO₃', description: 'Cosmetic ingredient' },
    
    // More Specialized Acids and Bases
    { id: 'edta', name: 'EDTA', type: 'acid', ph: 4.3, concentration: 0.1, color: 'text-yellow-600', formula: 'C₁₀H₁₆N₂O₈', description: 'Chelating agent' },
    { id: 'dtpa', name: 'DTPA', type: 'acid', ph: 4.3, concentration: 0.1, color: 'text-yellow-600', formula: 'C₁₄H₂₃N₃O₁₀', description: 'Chelating agent' },
    { id: 'nta', name: 'NTA', type: 'acid', ph: 3.0, concentration: 0.1, color: 'text-orange-400', formula: 'C₆H₉NO₆', description: 'Chelating agent' },
    { id: 'ida', name: 'IDA', type: 'acid', ph: 2.8, concentration: 0.1, color: 'text-orange-400', formula: 'C₄H₇NO₄', description: 'Chelating agent' },
    { id: 'ada', name: 'ADA Buffer', type: 'base', ph: 6.6, concentration: 0.1, color: 'text-gray-400', formula: 'C₆H₁₂N₂O₄', description: 'Good biological buffer' },
    { id: 'mes', name: 'MES Buffer', type: 'acid', ph: 6.1, concentration: 0.1, color: 'text-gray-400', formula: 'C₆H₁₃NO₄S', description: 'Biological buffer' },
    { id: 'mops', name: 'MOPS Buffer', type: 'base', ph: 7.2, concentration: 0.1, color: 'text-gray-400', formula: 'C₇H₁₅NO₄S', description: 'Biological buffer' },
    { id: 'pipes', name: 'PIPES Buffer', type: 'base', ph: 6.8, concentration: 0.1, color: 'text-gray-400', formula: 'C₈H₁₈N₂O₆S₂', description: 'Biological buffer' },
    { id: 'cacodylic', name: 'Cacodylic Acid', type: 'acid', ph: 6.2, concentration: 0.1, color: 'text-gray-400', formula: 'C₂H₇AsO₂', description: 'Organoarsenic buffer' },
    { id: 'glycine', name: 'Glycine', type: 'base', ph: 9.8, concentration: 0.1, color: 'text-green-500', formula: 'C₂H₅NO₂', description: 'Amino acid buffer' },
  ];

  // Filter solutions based on search and type
  const filteredSolutions = useMemo(() => {
    return allSolutions.filter(solution => {
      const matchesSearch = solution.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           solution.formula.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           solution.description.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesType = (solution.type === 'acid' && showAcids) || 
                         (solution.type === 'base' && showBases);
      return matchesSearch && matchesType;
    });
  }, [searchTerm, showAcids, showBases]);

  const acids = filteredSolutions.filter(s => s.type === 'acid');
  const bases = filteredSolutions.filter(s => s.type === 'base');

  // Bubble cleanup effect (copied from ReactionZone)
  useEffect(() => {
    const timer = setTimeout(() => {
      if (bubbles.length > 0) {
        setBubbles(prev => prev.slice(Math.floor(prev.length / 2)));
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [bubbles]);

  const performReaction = useCallback(() => {
    if (!selectedAcid || !selectedBase) return;

    setIsReacting(true);
    
    // Add splash effect when starting reaction
    setSplash(true);
    setTimeout(() => setSplash(false), 700);
    
    // Add initial bubbles
    const newBubbles = [...bubbles];
    for (let i = 0; i < 35; i++) {
      newBubbles.push(Math.random());
    }
    setBubbles(newBubbles);
    
    setTimeout(() => {
      const finalPh = (selectedAcid.ph + selectedBase.ph) / 2;
      const phDifference = Math.abs(selectedAcid.ph - selectedBase.ph);
      
      let safety: 'safe' | 'caution' | 'danger' = 'safe';
      let productColor = 'bg-gradient-to-b from-green-100/50 to-green-200/40 dark:from-green-800/40 dark:to-green-700/30';
      let animationType = 'neutralization';

      // Enhanced animations based on reaction severity
      if (phDifference > 12) {
        safety = 'danger';
        productColor = 'bg-gradient-to-b from-red-100/50 to-red-200/40 dark:from-red-800/40 dark:to-red-700/30';
        animationType = 'explosion';
        setExplosion(true);
        setHeatWaves(true);
        setFlames(true);
        setWindEffect(true);
        setPlasmaBurst(true);
        setTimeout(() => {
          setExplosion(false);
          setHeatWaves(false);
          setFlames(false);
          setWindEffect(false);
          setPlasmaBurst(false);
        }, 4000);
      } else if (phDifference > 8) {
        safety = 'caution';
        productColor = 'bg-gradient-to-b from-yellow-100/50 to-yellow-200/40 dark:from-yellow-800/40 dark:to-yellow-700/30';
        animationType = 'gas';
        setGas(true);
        setSteam(true);
        setWindEffect(true);
        setChemicalSpiral(true);
        setTimeout(() => {
          setGas(false);
          setSteam(false);
          setWindEffect(false);
          setChemicalSpiral(false);
        }, 5000);
      } else if (phDifference > 4) {
        safety = 'safe';
        productColor = 'bg-gradient-to-b from-blue-100/50 to-blue-200/40 dark:from-blue-800/40 dark:to-blue-700/30';
        animationType = 'neutralization';
        setColorChange(true);
        setSteam(true);
        setQuantumFlicker(true);
        setTimeout(() => {
          setColorChange(false);
          setSteam(false);
          setQuantumFlicker(false);
        }, 3500);
      }

      const result: ReactionResult = {
        product: `Salt + Water`,
        finalPh: finalPh,
        description: `${selectedAcid.name} + ${selectedBase.name} → Salt + Water. ${
          Math.abs(finalPh - 7) < 1 ? 'Complete neutralization achieved!' : 
          Math.abs(finalPh - 7) < 2 ? 'Good neutralization.' : 'Partial neutralization.'
        }`,
        animation: getAnimationClass(animationType as any),
        safety,
        productColor,
        isReacting: false
      };

      setReactionResult(result);
      setIsReacting(false);
    }, 2000);
  }, [selectedAcid, selectedBase, bubbles]);

  const resetLab = () => {
    setSelectedAcid(null);
    setSelectedBase(null);
    setReactionResult(null);
    setIsReacting(false);
    // Clear all animations
    setBubbles([]);
    setExplosion(false);
    setGas(false);
    setSplash(false);
    setSteam(false);
    setCrystallization(false);
    setHeatWaves(false);
    setColorChange(false);
    setPrecipitation(false);
    setFlames(false);
    setWindEffect(false);
    setPlasmaBurst(false);
    setRadioactiveGlow(false);
    setChemicalSpiral(false);
    setMolecularDance(false);
    setQuantumFlicker(false);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center gap-3">
              <Beaker className="h-8 w-8 text-primary" />
              <h1 className="text-4xl font-bold text-white">Acid-Base Reaction Lab</h1>
            </div>
            <p className="text-gray-300 max-w-2xl mx-auto">
              Experiment with acids and bases to understand neutralization reactions. 
              Mix different solutions and observe the pH changes in real-time.
            </p>
          </div>

          {/* Search and Filter Controls */}
          <Card className="glass-effect border-primary/20">
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4 items-center">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search acids and bases by name, formula, or description..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-800/50 border-gray-600"
                  />
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={showAcids ? "default" : "outline"}
                    size="sm"
                    onClick={() => setShowAcids(!showAcids)}
                    className={showAcids ? "bg-red-500/20 border-red-500 text-red-300" : ""}
                  >
                    Acids ({acids.length})
                  </Button>
                  <Button
                    variant={showBases ? "default" : "outline"}
                    size="sm"
                    onClick={() => setShowBases(!showBases)}
                    className={showBases ? "bg-blue-500/20 border-blue-500 text-blue-300" : ""}
                  >
                    Bases ({bases.length})
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Acid Solutions */}
            <Card className="glass-effect border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-400">
                  <Droplets className="h-5 w-5" />
                  Acid Solutions ({acids.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-96 overflow-y-auto">
                {acids.map((acid) => (
                  <Button
                    key={acid.id}
                    variant={selectedAcid?.id === acid.id ? "default" : "outline"}
                    className={`w-full justify-start text-left h-auto p-3 ${
                      selectedAcid?.id === acid.id ? 'bg-red-500/20 border-red-500' : ''
                    }`}
                    onClick={() => setSelectedAcid(acid)}
                  >
                    <div className="space-y-1 w-full">
                      <div className="flex items-center justify-between">
                        <span className={`font-semibold ${acid.color} text-sm`}>{acid.name}</span>
                        <Badge variant="secondary" className="bg-red-500/20 text-red-300 text-xs">
                          pH {acid.ph}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-400">{acid.formula}</div>
                      <div className="text-xs text-gray-500 line-clamp-2">{acid.description}</div>
                    </div>
                  </Button>
                ))}
                {acids.length === 0 && (
                  <div className="text-center text-gray-500 py-4">
                    No acids found matching your search
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Chemical Reactor - Exact Copy from ReactionZone */}
            <Card className="glass-effect border-purple-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-purple-400">
                  <Beaker className="h-5 w-5" />
                  Chemical Reactor
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="relative h-96 p-6 rounded-xl flex flex-col items-center justify-center overflow-hidden transition-all duration-300 shadow-lg bg-gradient-to-b from-blue-50/10 to-blue-100/20 dark:from-blue-900/10 dark:to-blue-800/5">
                  
                  {/* Enhanced Animation Effects - Exact Copy from ReactionZone */}
                  {plasmaBurst && (
                    <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden">
                      {[...Array(25)].map((_, i) => (
                        <div 
                          key={`plasma-${i}`}
                          className="absolute rounded-full"
                          style={{
                            width: Math.random() * 12 + 6 + 'px',
                            height: Math.random() * 12 + 6 + 'px',
                            left: Math.random() * 100 + '%',
                            top: Math.random() * 100 + '%',
                            background: `radial-gradient(circle, #60a5fa, #3b82f6, #1d4ed8)`,
                            boxShadow: '0 0 20px #3b82f6, 0 0 40px #60a5fa',
                            animation: `plasma-pulse ${Math.random() * 1 + 0.5}s ease-in-out infinite alternate`,
                            opacity: Math.random() * 0.9 + 0.1
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {radioactiveGlow && (
                    <div className="absolute inset-0 z-15 pointer-events-none">
                      <div className="absolute inset-0 bg-gradient-radial from-green-400/30 via-yellow-400/20 to-transparent animate-pulse"></div>
                      {[...Array(30)].map((_, i) => (
                        <div 
                          key={`radiation-${i}`}
                          className="absolute bg-green-400/60 rounded-full"
                          style={{
                            width: Math.random() * 8 + 3 + 'px',
                            height: Math.random() * 8 + 3 + 'px',
                            left: Math.random() * 100 + '%',
                            top: Math.random() * 100 + '%',
                            animation: `radioactive-glow ${Math.random() * 2 + 1}s ease-in-out infinite`,
                            boxShadow: '0 0 15px #4ade80',
                            opacity: Math.random() * 0.8 + 0.2
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {chemicalSpiral && (
                    <div className="absolute inset-0 z-15 pointer-events-none overflow-hidden">
                      {[...Array(20)].map((_, i) => {
                        const angle = (i / 20) * Math.PI * 2;
                        const radius = 50 + Math.sin(Date.now() * 0.001 + i) * 30;
                        return (
                          <div 
                            key={`spiral-${i}`}
                            className="absolute bg-purple-400/50 rounded-full"
                            style={{
                              width: '6px',
                              height: '6px',
                              left: `calc(50% + ${Math.cos(angle) * radius}px)`,
                              top: `calc(50% + ${Math.sin(angle) * radius}px)`,
                              animation: `chemical-spiral ${3 + Math.random()}s linear infinite`,
                              animationDelay: `${i * 0.1}s`,
                              boxShadow: '0 0 10px #a855f7'
                            }}
                          ></div>
                        );
                      })}
                    </div>
                  )}

                  {molecularDance && (
                    <div className="absolute inset-0 z-15 pointer-events-none overflow-hidden">
                      {[...Array(15)].map((_, i) => (
                        <div 
                          key={`molecule-${i}`}
                          className="absolute bg-indigo-400/70 rounded-full"
                          style={{
                            width: Math.random() * 10 + 5 + 'px',
                            height: Math.random() * 10 + 5 + 'px',
                            left: Math.random() * 80 + 10 + '%',
                            top: Math.random() * 80 + 10 + '%',
                            animation: `molecular-dance ${Math.random() * 3 + 2}s ease-in-out infinite`,
                            animationDelay: Math.random() * 1 + 's',
                            boxShadow: '0 0 15px #6366f1'
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {quantumFlicker && (
                    <div className="absolute inset-0 z-15 pointer-events-none">
                      {[...Array(40)].map((_, i) => (
                        <div 
                          key={`quantum-${i}`}
                          className="absolute bg-cyan-400/60 rounded-full"
                          style={{
                            width: Math.random() * 4 + 2 + 'px',
                            height: Math.random() * 4 + 2 + 'px',
                            left: Math.random() * 100 + '%',
                            top: Math.random() * 100 + '%',
                            animation: `quantum-flicker ${Math.random() * 0.5 + 0.2}s ease-in-out infinite`,
                            animationDelay: Math.random() * 0.5 + 's',
                            boxShadow: '0 0 8px #22d3ee',
                            opacity: Math.random() * 0.9 + 0.1
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {flames && (
                    <div className="absolute inset-0 z-15 pointer-events-none overflow-hidden">
                      {[...Array(18)].map((_, i) => (
                        <div 
                          key={`flame-${i}`}
                          className="absolute"
                          style={{
                            width: Math.random() * 25 + 12 + 'px',
                            height: Math.random() * 50 + 25 + 'px',
                            left: Math.random() * 60 + 20 + '%',
                            bottom: Math.random() * 30 + 10 + '%',
                            background: 'linear-gradient(to top, #dc2626, #f97316, #fbbf24, #fef3c7)',
                            borderRadius: '50% 50% 50% 50% / 60% 60% 40% 40%',
                            animation: `flame-flicker ${Math.random() * 0.4 + 0.2}s ease-in-out infinite alternate`,
                            filter: 'blur(1px)',
                            opacity: Math.random() * 0.9 + 0.1,
                            boxShadow: '0 0 20px #f97316'
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {windEffect && (
                    <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
                      {[...Array(20)].map((_, i) => (
                        <div 
                          key={`wind-${i}`}
                          className="absolute bg-white/20 rounded-full"
                          style={{
                            width: Math.random() * 4 + 1 + 'px',
                            height: Math.random() * 4 + 1 + 'px',
                            left: Math.random() * 100 + '%',
                            top: Math.random() * 100 + '%',
                            animation: `wind-blow ${Math.random() * 2 + 1}s linear infinite`,
                            animationDelay: Math.random() * 1 + 's'
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {heatWaves && (
                    <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
                      {[...Array(15)].map((_, i) => (
                        <div 
                          key={`heat-${i}`}
                          className="absolute bg-gradient-to-t from-orange-400/30 to-red-400/20 rounded-full"
                          style={{
                            width: Math.random() * 80 + 40 + 'px',
                            height: Math.random() * 120 + 60 + 'px',
                            left: Math.random() * 80 + 10 + '%',
                            top: Math.random() * 60 + 20 + '%',
                            animation: `gas-rise ${Math.random() * 2 + 1}s ease-out infinite`,
                            animationDelay: Math.random() * 1 + 's',
                            filter: 'blur(3px)'
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {explosion && (
                    <div className="absolute inset-0 z-10">
                      <div className="absolute inset-0 bg-gradient-to-br from-orange-400/30 via-red-400/20 to-yellow-300/10"></div>
                      {[...Array(80)].map((_, i) => (
                        <div 
                          key={i} 
                          className="absolute"
                          style={{
                            width: Math.random() * 12 + 3 + 'px',
                            height: Math.random() * 3 + 1 + 'px',
                            left: 50 + Math.random() * 20 - 10 + '%',
                            top: 50 + Math.random() * 20 - 10 + '%',
                            background: `linear-gradient(${Math.random() * 360}deg, #fbbf24, #f59e0b, #d97706)`,
                            opacity: Math.random() * 0.9 + 0.1,
                            animation: `explosion-particle ${Math.random() * 2 + 1}s ease-out forwards`,
                            transform: `rotate(${Math.random() * 360}deg)`,
                            '--x-move': `${(Math.random() - 0.5) * 500}px`,
                            '--y-move': `${(Math.random() - 0.5) * 500}px`,
                          } as React.CSSProperties}
                        ></div>
                      ))}
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-0 h-0 border-orange-400/50 animate-ping" 
                             style={{
                               borderWidth: '150px',
                               borderStyle: 'solid',
                               borderRadius: '50%',
                               animation: 'shock-wave 1.5s ease-out'
                             }}>
                        </div>
                      </div>
                    </div>
                  )}
                  
                  {gas && (
                    <div className="absolute inset-0 z-10 pointer-events-none overflow-hidden">
                      {[...Array(35)].map((_, i) => (
                        <div 
                          key={i} 
                          className="absolute rounded-full"
                          style={{
                            width: Math.random() * 60 + 15 + 'px',
                            height: Math.random() * 60 + 15 + 'px',
                            left: Math.random() * 80 + 10 + '%',
                            top: Math.random() * 30 + 60 + '%',
                            background: `hsla(${Math.random() * 120 + 60}, 70%, 60%, 0.4)`,
                            animationDuration: Math.random() * 4 + 2 + 's',
                            animationDelay: Math.random() * 2 + 's',
                            animation: `gas-rise ${Math.random() * 4 + 2}s ease-out infinite`,
                            filter: 'blur(2px)'
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {steam && (
                    <div className="absolute inset-0 z-15 pointer-events-none overflow-hidden">
                      {[...Array(50)].map((_, i) => (
                        <div 
                          key={`steam-${i}`}
                          className="absolute bg-white/40 rounded-full"
                          style={{
                            width: Math.random() * 40 + 8 + 'px',
                            height: Math.random() * 40 + 8 + 'px',
                            left: Math.random() * 70 + 15 + '%',
                            top: Math.random() * 20 + 50 + '%',
                            animationDuration: Math.random() * 5 + 2 + 's',
                            animationDelay: Math.random() * 1 + 's',
                            animation: `gas-rise ${Math.random() * 5 + 2}s ease-out infinite`,
                            filter: 'blur(3px)',
                            opacity: Math.random() * 0.6 + 0.2
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {precipitation && (
                    <div className="absolute inset-0 z-15 pointer-events-none overflow-hidden">
                      {[...Array(30)].map((_, i) => (
                        <div 
                          key={`precipitate-${i}`}
                          className="absolute animate-fall"
                          style={{
                            width: Math.random() * 6 + 2 + 'px',
                            height: Math.random() * 6 + 2 + 'px',
                            left: Math.random() * 70 + 15 + '%',
                            top: Math.random() * 40 + 20 + '%',
                            background: 'linear-gradient(45deg, #f0f9ff, #dbeafe, #bfdbfe)',
                            borderRadius: '50%',
                            animationDuration: Math.random() * 3 + 1 + 's',
                            animationDelay: Math.random() * 0.5 + 's',
                            opacity: Math.random() * 0.8 + 0.3
                          }}
                        ></div>
                      ))}
                    </div>
                  )}

                  {colorChange && (
                    <div className="absolute inset-0 z-5 pointer-events-none">
                      <div 
                        className="absolute bottom-0 w-full h-3/4 rounded-b-2xl transition-all duration-2000"
                        style={{
                          background: 'linear-gradient(to top, #fef3c7, #fde68a, #fcd34d)',
                          animation: 'pulse 2s ease-in-out'
                        }}
                      ></div>
                    </div>
                  )}

                  {splash && (
                    <div className="absolute inset-0 z-20 pointer-events-none overflow-hidden">
                      {[...Array(20)].map((_, i) => (
                        <div 
                          key={`splash-${i}`}
                          className="absolute bg-blue-400/70 dark:bg-blue-500/50"
                          style={{
                            width: Math.random() * 8 + 2 + 'px',
                            height: Math.random() * 16 + 10 + 'px',
                            left: 40 + Math.random() * 20 + '%',
                            top: 40 + Math.random() * 10 + '%',
                            borderRadius: '50% 50% 0 0',
                            transform: `rotate(${Math.random() * 360}deg)`,
                            opacity: Math.random() * 0.8 + 0.3,
                            animation: `splash-rise ${Math.random() * 0.8 + 0.5}s ease-out forwards`,
                          }}
                        ></div>
                      ))}
                    </div>
                  )}
                  
                  {/* Perfectly Centered Beaker - Exact Copy from ReactionZone */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="relative w-56 h-64 mx-auto">
                        <div className="absolute bottom-0 w-full h-full rounded-b-3xl rounded-t-lg overflow-hidden">
                          <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/15 to-transparent border-2 border-gray-300/50 rounded-b-3xl rounded-t-lg backdrop-blur-sm shadow-2xl">
                            <div className="absolute top-8 left-4 w-16 h-32 bg-white/25 rounded-full transform -rotate-12 blur-sm"></div>
                            <div className="absolute top-12 right-6 w-8 h-24 bg-white/20 rounded-full transform rotate-12 blur-sm"></div>
                            <div className="absolute bottom-16 left-8 w-12 h-16 bg-white/15 rounded-full transform -rotate-45 blur-sm"></div>
                            
                            <div className="absolute inset-0 border border-gray-200/40 rounded-b-3xl rounded-t-lg"></div>
                            <div className="absolute inset-1 border border-gray-100/30 rounded-b-3xl rounded-t-lg"></div>
                          </div>
                          
                          <div className="absolute -top-[1px] left-[8%] w-[35%] h-5 border-t-2 border-l-2 border-r-2 border-gray-300/50 bg-gradient-to-b from-white/8 to-transparent" 
                               style={{ clipPath: 'polygon(0 0, 85% 0, 100% 100%, 15% 100%)' }}>
                            <div className="absolute top-0 left-2 w-4 h-2 bg-white/15 rounded-full blur-sm"></div>
                          </div>
                          
                          <div className="absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-48 h-4 bg-black/15 rounded-full blur-lg"></div>
                        </div>

                        <div className={`absolute bottom-0 w-full transition-all duration-700 ease-out overflow-hidden rounded-b-2xl ${(selectedAcid && selectedBase) ? 'h-[70%]' : 'h-[15%]'}`}>
                          <div className={`w-full h-full relative ${reactionResult?.productColor ? reactionResult.productColor : 'bg-gradient-to-b from-blue-100/50 to-blue-200/40 dark:from-blue-800/40 dark:to-blue-700/30'} ${isReacting ? 'animate-pulse' : ''}`}>
                            <div className="absolute inset-x-0 top-0 h-2 bg-gradient-to-b from-white/60 via-white/30 to-transparent rounded-full"></div>
                            <div className="absolute inset-x-2 top-0 h-1 bg-white/40 rounded-full"></div>
                            
                            {bubbles.map((bubble, index) => (
                                <div key={index} 
                                     className="absolute rounded-full bg-white/90 dark:bg-white/60 animate-rise shadow-lg" 
                                     style={{
                                        width: Math.max(4, Math.random() * 12) + 'px',
                                        height: Math.max(4, Math.random() * 12) + 'px',
                                        bottom: bubble * 100 + '%',
                                        left: Math.random() * 80 + 10 + '%',
                                        animationDuration: Math.random() * 2 + 1 + 's',
                                        opacity: Math.random() * 0.8 + 0.2,
                                        boxShadow: 'inset 0 0 4px rgba(255,255,255,0.9), 0 0 4px rgba(0,0,0,0.2)'
                                     }} />
                            ))}
                            
                            {(selectedAcid && selectedBase) && (
                              <>
                                <div className="absolute bottom-0 w-full h-1/4 bg-gradient-to-t from-black/15 to-transparent"></div>
                                <div className="absolute bottom-1/4 w-full h-1 bg-gradient-to-r from-transparent via-white/30 to-transparent"></div>
                              </>
                            )}
                          </div>
                        </div>

                        {/* Chemical Info Overlay */}
                        {selectedAcid && (
                          <div className="absolute top-4 left-0 p-2 bg-red-500/20 rounded-lg border border-red-500/30 backdrop-blur-sm">
                            <div className="text-xs text-red-300 font-semibold">{selectedAcid.name}</div>
                            <div className="text-xs text-red-400">{selectedAcid.formula}</div>
                            <Badge className="mt-1 bg-red-500/30 text-red-300 text-xs">pH {selectedAcid.ph}</Badge>
                          </div>
                        )}
                        
                        {selectedBase && (
                          <div className="absolute top-4 right-0 p-2 bg-blue-500/20 rounded-lg border border-blue-500/30 backdrop-blur-sm">
                            <div className="text-xs text-blue-300 font-semibold">{selectedBase.name}</div>
                            <div className="text-xs text-blue-400">{selectedBase.formula}</div>
                            <Badge className="mt-1 bg-blue-500/30 text-blue-300 text-xs">pH {selectedBase.ph}</Badge>
                          </div>
                        )}

                        {reactionResult && (
                          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 p-3 bg-green-500/20 rounded-lg text-center border border-green-500/30 backdrop-blur-sm">
                            <div className="text-sm text-green-300 font-semibold">
                              {reactionResult.product}
                            </div>
                            <div className="text-lg font-bold text-green-300 mt-1">
                              Final pH: {reactionResult.finalPh.toFixed(1)}
                            </div>
                            <div className="text-xs text-green-400 mt-1">
                              {reactionResult.description}
                            </div>
                          </div>
                        )}

                        {!selectedAcid && !selectedBase && (
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="text-center text-gray-500">
                              <Beaker className="h-8 w-8 mx-auto mb-2 opacity-50" />
                              <p>Select an acid and base to begin</p>
                            </div>
                          </div>
                        )}
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Button 
                    onClick={performReaction}
                    disabled={!selectedAcid || !selectedBase || isReacting}
                    className="w-full bg-purple-600 hover:bg-purple-700"
                  >
                    {isReacting ? 'Reacting...' : 'Mix Solutions'}
                  </Button>
                  <Button 
                    onClick={resetLab}
                    variant="outline"
                    className="w-full"
                  >
                    <RotateCcw className="h-4 w-4 mr-2" />
                    Reset Lab
                  </Button>
                </div>

                {reactionResult && (
                  <Alert className={`${
                    reactionResult.safety === 'danger' ? 'border-red-500/50 bg-red-500/10' :
                    reactionResult.safety === 'caution' ? 'border-yellow-500/50 bg-yellow-500/10' :
                    'border-green-500/50 bg-green-500/10'
                  }`}>
                    {reactionResult.safety === 'danger' ? <AlertTriangle className="h-4 w-4" /> :
                     reactionResult.safety === 'caution' ? <AlertTriangle className="h-4 w-4" /> :
                     <CheckCircle className="h-4 w-4" />}
                    <AlertDescription className="text-sm">
                      Safety Level: {reactionResult.safety.toUpperCase()} - 
                      {reactionResult.safety === 'danger' ? ' Extreme reaction! Handle with care.' :
                       reactionResult.safety === 'caution' ? ' Moderate reaction, use caution.' :
                       ' Safe reaction, well neutralized.'}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>

            {/* Base Solutions */}
            <Card className="glass-effect border-blue-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-blue-400">
                  <Droplets className="h-5 w-5" />
                  Base Solutions ({bases.length})
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 max-h-96 overflow-y-auto">
                {bases.map((base) => (
                  <Button
                    key={base.id}
                    variant={selectedBase?.id === base.id ? "default" : "outline"}
                    className={`w-full justify-start text-left h-auto p-3 ${
                      selectedBase?.id === base.id ? 'bg-blue-500/20 border-blue-500' : ''
                    }`}
                    onClick={() => setSelectedBase(base)}
                  >
                    <div className="space-y-1 w-full">
                      <div className="flex items-center justify-between">
                        <span className={`font-semibold ${base.color} text-sm`}>{base.name}</span>
                        <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 text-xs">
                          pH {base.ph}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-400">{base.formula}</div>
                      <div className="text-xs text-gray-500 line-clamp-2">{base.description}</div>
                    </div>
                  </Button>
                ))}
                {bases.length === 0 && (
                  <div className="text-center text-gray-500 py-4">
                    No bases found matching your search
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* pH Scale Reference with Real-Time Value */}
          <Card className="glass-effect">
            <CardHeader>
              <CardTitle className="text-primary">pH Scale Reference</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-7 gap-2 text-center text-xs">
                  <div className="p-2 bg-red-600 rounded">0-2<br/>Strong Acid</div>
                  <div className="p-2 bg-red-400 rounded">3-4<br/>Weak Acid</div>
                  <div className="p-2 bg-orange-400 rounded">5-6<br/>Slightly Acidic</div>
                  <div className="p-2 bg-green-500 rounded">7<br/>Neutral</div>
                  <div className="p-2 bg-blue-400 rounded">8-9<br/>Slightly Basic</div>
                  <div className="p-2 bg-blue-600 rounded">10-11<br/>Weak Base</div>
                  <div className="p-2 bg-blue-800 rounded">12-14<br/>Strong Base</div>
                </div>
                <div className="relative">
                  <Progress 
                    value={reactionResult ? (reactionResult.finalPh / 14) * 100 : 50} 
                    className="h-4" 
                  />
                  {reactionResult && (
                    <div 
                      className="absolute top-0 transform -translate-x-1/2 -translate-y-8"
                      style={{ left: `${(reactionResult.finalPh / 14) * 100}%` }}
                    >
                      <div className="bg-white text-black px-2 py-1 rounded text-xs font-bold">
                        pH {reactionResult.finalPh.toFixed(1)}
                      </div>
                    </div>
                  )}
                </div>
                <div className="flex justify-between text-xs text-gray-400">
                  <span>More Acidic (0)</span>
                  <span>Neutral (7)</span>
                  <span>More Basic (14)</span>
                </div>
                {reactionResult && (
                  <div className="text-center p-3 bg-purple-500/20 rounded-lg border border-purple-500/30">
                    <div className="text-lg font-bold text-purple-300">
                      Current Reaction pH: {reactionResult.finalPh.toFixed(1)}
                    </div>
                    <div className="text-sm text-purple-400">
                      {reactionResult.finalPh < 7 ? 'Acidic Solution' : 
                       reactionResult.finalPh > 7 ? 'Basic Solution' : 'Neutral Solution'}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DndProvider>
  );
};

export default AcidBaseLab;