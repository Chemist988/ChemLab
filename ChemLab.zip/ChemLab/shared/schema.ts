import { pgTable, text, integer, timestamp, boolean, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  username: text("username").unique().notNull(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const experiments = pgTable("experiments", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("user_id").references(() => users.id),
  experimentType: text("experiment_type").notNull(), // 'reaction', 'acid-base', 'formula-builder'
  elementSymbols: text("element_symbols").array(), // Array of element symbols used
  result: text("result").notNull(),
  description: text("description").notNull(),
  phBefore: real("ph_before"), // For acid-base experiments
  phAfter: real("ph_after"), // For acid-base experiments
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reactionLogs = pgTable("reaction_logs", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("user_id").references(() => users.id),
  element1Symbol: text("element1_symbol").notNull(),
  element2Symbol: text("element2_symbol").notNull(),
  product: text("product").notNull(),
  animationType: text("animation_type").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const quizResults = pgTable("quiz_results", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  userId: integer("user_id").references(() => users.id),
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  topic: text("topic").notNull(), // 'periodic-table', 'reactions', 'acids-bases'
  completedAt: timestamp("completed_at").defaultNow().notNull(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  experiments: many(experiments),
  reactionLogs: many(reactionLogs),
  quizResults: many(quizResults),
}));

export const experimentsRelations = relations(experiments, ({ one }) => ({
  user: one(users, {
    fields: [experiments.userId],
    references: [users.id],
  }),
}));

export const reactionLogsRelations = relations(reactionLogs, ({ one }) => ({
  user: one(users, {
    fields: [reactionLogs.userId],
    references: [users.id],
  }),
}));

export const quizResultsRelations = relations(quizResults, ({ one }) => ({
  user: one(users, {
    fields: [quizResults.userId],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertExperimentSchema = createInsertSchema(experiments).omit({
  id: true,
  createdAt: true,
});

export const insertReactionLogSchema = createInsertSchema(reactionLogs).omit({
  id: true,
  createdAt: true,
});

export const insertQuizResultSchema = createInsertSchema(quizResults).omit({
  id: true,
  completedAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertExperiment = z.infer<typeof insertExperimentSchema>;
export type Experiment = typeof experiments.$inferSelect;
export type InsertReactionLog = z.infer<typeof insertReactionLogSchema>;
export type ReactionLog = typeof reactionLogs.$inferSelect;
export type InsertQuizResult = z.infer<typeof insertQuizResultSchema>;
export type QuizResult = typeof quizResults.$inferSelect;
